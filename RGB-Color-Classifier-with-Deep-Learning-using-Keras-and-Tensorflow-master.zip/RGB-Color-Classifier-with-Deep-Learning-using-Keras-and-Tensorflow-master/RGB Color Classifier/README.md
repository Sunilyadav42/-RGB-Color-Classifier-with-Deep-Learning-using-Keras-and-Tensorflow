If Github is Unable to Render the Jupyter Notebook (.ipynb), 

You can Click Here: [Classify_an_image_input_generated_from_random_RGB_values.ipynb](https://nbviewer.jupyter.org/github/AjinkyaChavan9/RGB-Color-Classifier-with-Deep-Learning-using-Keras-and-Tensorflow/blob/master/RGB%20Color%20Classifier/Classify_an_image_input_generated_from_random_RGB_values.ipynb)

OR

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/AjinkyaChavan9/RGB-Color-Classifier-with-Deep-Learning-using-Keras-and-Tensorflow/blob/master/RGB%20Color%20Classifier/Classify_an_image_input_generated_from_random_RGB_values.ipynb)
